package com.sunli.decembermultiple.shell_frame.network;

public class Constants {
    /**
     * 注册
     */
    public static final String POST_BODY_KEY_REGISTER_PHONE = "phone";
    public static final String POST_BODY_KEY_REGISTER_PASSWORD = "pwd";
    /**
     * 登录
     */
    public static final String POST_BODY_KEY_LOGIN_PHONE = "phone";
    public static final String POST_BODY_KEY_LOGIN_PASSWORD = "pwd";
/*    *//**
     * 首页条目查询
     *//*
    //一级
    public static final String GET_BODY_KEY_FIND_FIRST_CATEGORY_ID = "id";
    public static final String GET_BODY_KEY_FIND_FIRST_CATEGORY_NAME = "name";
    //二级
    public static final String GET_BODY_KEY_FIND_SECOND_CATEGORY_ID = "id";
    public static final String GET_BODY_KEY_FIND_SECONDCATEGORY_NAME = "name";*/
}
