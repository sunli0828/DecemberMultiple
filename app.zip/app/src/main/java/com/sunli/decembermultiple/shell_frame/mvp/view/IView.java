package com.sunli.decembermultiple.shell_frame.mvp.view;

public interface IView {
    void showResponseData(Object data);
    void showResponseFail(String e);
}
