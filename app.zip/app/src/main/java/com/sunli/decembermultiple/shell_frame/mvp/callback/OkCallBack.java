package com.sunli.decembermultiple.shell_frame.mvp.callback;

public interface OkCallBack {
    void success(Object data);
    void fail(Exception e);
}
